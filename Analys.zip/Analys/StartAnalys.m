clear
Fas = 'Vila'; %Ange f�r namngivning av figur
Patientnamn = 'Rimaz';
Mappindex = '2';
c =4; %Ange vilken kolumn
load(['Rimaz2.mat']) %Ange filnam
Input = DefaultTrialSession5Shimmer9DF2CalibratedPC; %Ange matrisnamn
fs = 512; %Sample rate (Hz);
x_lim = [0,60]; %Ange xlimit [start,stop}
Bredd = 0.04; %Minsta bredd p� R-peak. Skjusteras om resultatet f�r momentanpuls inte fungerar som det ska
Analys
Sparafig