mkdir ('../Analys/Testdatabas/', [Patientnamn, '/Test',Mappindex,'/']);
Sparasom1 = ['../Analys/Testdatabas/', Patientnamn, '/Test',Mappindex,'/',Patientnamn,Mappindex,' ',Fas,' Figur1'];
Sparasom2 = ['../Analys/Testdatabas/', Patientnamn, '/Test',Mappindex,'/',Patientnamn,Mappindex,' ',Fas,' Figur2'];
saveas(1, Sparasom1,'jpeg')
saveas(2, Sparasom2,'jpeg')