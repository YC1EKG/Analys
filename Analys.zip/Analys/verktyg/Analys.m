%% Filtrering
HPF = 1;
LPF = 1;
BSF = 1;
fm = 50;                                                                   % mains frequency [Hz]
    fchp = 0.5;                                                                % corner frequency highpassfilter [Hz]; Shimmer recommends 0.5Hz for monitoring applications, 0.05Hz for diagnostic settings
    nPoles = 4;                                                                % number of poles (HPF, LPF)
    pbRipple = 0.5;
  ECG_mV = Input(:,c);
  
  if HPF
  hpfexg1ch1 = FilterClass(FilterClass.HPF,fs,fchp,nPoles,pbRipple);
  ECG_mV = hpfexg1ch1.filterData(ECG_mV);
  end
  
  if LPF
  lpfexg1ch1 = FilterClass(FilterClass.LPF,fs,fs/2-1,nPoles,pbRipple);
  ECG_mV = lpfexg1ch1.filterData(ECG_mV);
  end
  if BSF
  bsfexg1ch1 = FilterClass(FilterClass.LPF,fs,[fm-1,fm+1],nPoles,pbRipple);
  ECG_mV = bsfexg1ch1.filterData(ECG_mV);
  end
%% Analys av EKG

t = (1:length(ECG_mV))/fs; %Tid i s
r=(1/(2^2))*fs;
R_peak = 0;
for sample = (fs+1):(r):(length(ECG_mV)-0.5*fs)
ECG_max = max(ECG_mV((sample-fs):(sample+0.5*fs)));
[~,locs_Rwave] = findpeaks(ECG_mV((sample-fs):(sample+0.5*fs)),'Minpeakheight', 0.3*ECG_max, 'MinPeakDistance', 0.25*fs, 'MinPeakProminence',0.7, 'WidthReference','halfprom', 'MaxPeakWidth', Bredd*fs); %Hittar R-delen
locs_Rwave = (sample-fs+locs_Rwave)';
R_peak = [R_peak locs_Rwave];
end
locs_Rwave = R_peak(2:end)';
locs_Rwave = unique(locs_Rwave);
for sample = 1:length(locs_Rwave)-1
    Rpeak_less(sample,1) = (locs_Rwave(sample)<locs_Rwave(sample+1));
end
locs_Rwave = locs_Rwave(Rpeak_less);
RRdiff = diff(locs_Rwave);
HR_big = RRdiff>0.25*fs;
locs_Rwave = locs_Rwave(HR_big);
g(1:length(locs_Rwave)-1,1) = 0;
minut = 1;
for p= 1:length(locs_Rwave)-1
    if locs_Rwave(p)>60*fs*minut
        minut=minut+1;
    end
g(p,minut) = locs_Rwave(p+1)/fs-locs_Rwave(p)/fs;
end
MomHR = 60./abs(g);
gsqr = sum(g.^2);
RMSSD = 10^3*sqrt(gsqr/(length(locs_Rwave)-1));
g0 = g ~=0;
g = g(g0);
%Medelpuls/min
HR_min = zeros(round(t(end)/60),1);
minut = 0;
for sample = 1:60*fs:length(ECG_mV)
    R60=0;
    R60 = locs_Rwave(locs_Rwave > sample)<sample+60*fs;
minut = minut+1;
HR_min(minut,1) = sum(R60);
end
HR_all = 60*(length(locs_Rwave)-1)/((locs_Rwave(end)-locs_Rwave(1))/fs);
%% Plot av EKG
figure
subplot(2,1,1)
hold on
plot(t,ECG_mV)
plot(locs_Rwave/fs,ECG_mV(locs_Rwave),'rv','MarkerFaceColor','r')
xlabel('Tid (s)');
ylabel('Voltage(mV)');
legend('ECG-exempel', 'R-peak');
grid on;
xlim([x_lim(1) x_lim(2)]) %Justerar x-axel
ylim([(min(ECG_mV)-0.1*min(ECG_mV)) (max(ECG_mV)+0.1*max(ECG_mV))]) %Justerar y-axel 
subplot(2,1,2)
grid on
plot((locs_Rwave(1:end-1))/fs,MomHR)
xlabel ('Tid (s)');
ylabel ('Puls')
legend ('Momentanpuls')

figure
subplot(3,1,1)
hold on
grid on
if round(t(end))>60
plot(HR_min,'-rd')
plot(HR_all, 'bs')
xlabel ('Tid (min)')
ylabel('Puls')
legend('HR min', 'HR hela')
else
plot(HR_all, 'bs')
xlabel ('Tid (min)')
ylabel('Puls')
legend('HR hela')
end
subplot(3,1,2)
grid on
plot(RMSSD)
ylabel ('ms')
xlabel ('Tid i min')
legend('RMSSD')
subplot(3,1,3)
plot(locs_Rwave(1:end-1)/fs,g)
ylabel ('Skillnad (s)')
xlabel('Tid (s)')
legend ('R-R skillnad')
%% Medelpuls

RMSSD
HR_all
